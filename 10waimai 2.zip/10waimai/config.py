class Config():
    # 设置连接数据库的URL
    SQLALCHEMY_DATABASE_URI = 'mysql://root:123456@127.0.0.1:3306/db_10_waimai'

    # 数据库和模型类同步修改
    SQLALCHEMY_TRACK_MODIFICATIONS = True

    # 查询时会显示原始SQL语句
    SQLALCHEMY_ECHO = False

    APP_ID = 'wx98d9a7f454d7d6d9'
    SECRET = '8f5bbd462640d2495f0193c5b20cb033'
    MCH_ID = '123456'  # 商户号
    notify_url = 'https://127.0.0.1/api/v1/order/callback'
    PAYKEY = 'PA3127312836126'  # 商户密钥

    BABEL_DEFAULT_LOCALE = 'zh_CN'  # 汉化

    SECRET_KEY = 'asjdjkhask%&^%$%&*('

    DOMAIN = 'http://127.0.0.1:5000/static/'


class Product(Config):  # 线上
    DEBUG = False


class Dev(Config):  # 开发
    DEBUG = True


config_mapping = {
    'pro': Product,
    'dev': Dev
}
