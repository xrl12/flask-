//获取应用实例
var app = getApp();
Page({
    data: {
        "content": "非常愉快的订餐体验~~",
        "score": 10,
        "order_sn": ""
    },
    onLoad: function (e) {
        console.log()
        this.setData({
            order_sn: e.order_number
        })

    },
    scoreChange: function (e) {
        this.setData({
            "score": e.detail.value
        });
    },
    doComment: function () {
        var that = this;
        wx.request({
            url: app.buildUrl("/my/comment/add"),
            header: app.getRequestHeader(),
            method: 'POST',

            data: {
                content: that.data.content,
                score: that.data.score,
                order_sn: that.data.order_sn

            },
            success: function (res) {
                var resp = res.data;
                if (resp.code != 200) {
                    app.alert({"content": resp.msg});
                    return;
                }
                that.setData({
                    user_info: resp.data.info
                });
            }
        })
        ;
    },
    contentInput: function (e) {
        this.setData({
            content: e.detail.value
        })

    }
});