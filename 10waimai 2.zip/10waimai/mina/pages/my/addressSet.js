//获取应用实例
var commonCityData = require('../../utils/city.js');
var app = getApp();
Page({
    data: {
        provinces: [],
        citys: [],
        districts: [],
        selProvince: '请选择',
        selCity: '请选择',
        selDistrict: '请选择',
        selProvinceIndex: 0,
        selCityIndex: 0,
        selDistrictIndex: 0
    },
    onLoad: function (e) {
        var that = this;
        this.initCityData(1);
    },
    //初始化城市数据
    initCityData: function (level, obj) {
        if (level == 1) {
            var pinkArray = [];
            for (var i = 0; i < commonCityData.cityData.length; i++) {
                pinkArray.push(commonCityData.cityData[i].name);
            }
            this.setData({
                provinces: pinkArray
            });
        } else if (level == 2) {
            var pinkArray = [];
            var dataArray = obj.cityList
            for (var i = 0; i < dataArray.length; i++) {
                pinkArray.push(dataArray[i].name);
            }
            this.setData({
                citys: pinkArray
            });
        } else if (level == 3) {
            var pinkArray = [];
            var dataArray = obj.districtList
            for (var i = 0; i < dataArray.length; i++) {
                pinkArray.push(dataArray[i].name);
            }
            this.setData({
                districts: pinkArray
            });
        }
    },
    bindPickerProvinceChange: function (event) {
        var selIterm = commonCityData.cityData[event.detail.value];
        this.setData({
            selProvince: selIterm.name,
            selProvinceIndex: event.detail.value,
            selCity: '请选择',
            selCityIndex: 0,
            selDistrict: '请选择',
            selDistrictIndex: 0
        });
        this.initCityData(2, selIterm);
    },
    bindPickerCityChange: function (event) {
        var selIterm = commonCityData.cityData[this.data.selProvinceIndex].cityList[event.detail.value];
        this.setData({
            selCity: selIterm.name,
            selCityIndex: event.detail.value,
            selDistrict: '请选择',
            selDistrictIndex: 0
        });
        this.initCityData(3, selIterm);
    },
    bindPickerChange: function (event) {
        var selIterm = commonCityData.cityData[this.data.selProvinceIndex].cityList[this.data.selCityIndex].districtList[event.detail.value];
        if (selIterm && selIterm.name && event.detail.value) {
            this.setData({
                selDistrict: selIterm.name,
                selDistrictIndex: event.detail.value
            })
        }
    },
    bindCancel: function () {
        wx.navigateBack({});
    },
    nameinput: function (e) {


        this.setData({
            name: e.detail.value
        })
    },
    phoneinput: function (e) {
        this.setData({
            phone: e.detail.value
        })

    },

    addressinput: function (e) {
        this.setData({
            address: e.detail.value
        })
    },
    bindSave: function (e) {
        var that = this
        var province_id = commonCityData.cityData[this.data.selProvinceIndex].id
        var province_str = commonCityData.cityData[this.data.selProvinceIndex].name
        var city_id = commonCityData.cityData[this.data.selProvinceIndex].cityList[this.data.selCityIndex].id
        var city_str = commonCityData.cityData[this.data.selProvinceIndex].cityList[this.data.selCityIndex].name

        var area_id = ''
        var area_str = ''
        if (that.data.selDistrictIndex != 0) {

            area_id = commonCityData.cityData[this.data.selProvinceIndex].cityList[this.data.selCityIndex].districtList[this.data.selDistrictIndex].id
            area_str = commonCityData.cityData[this.data.selProvinceIndex].cityList[this.data.selCityIndex].districtList[this.data.selDistrictIndex].name
        }
        wx.request({
            url: app.buildUrl('/v1/address/set'),
            method: "POST",
            data: {
                nickname: that.data.name,
                mobile: that.data.phone,
                province_id: province_id,
                province_str: province_str,
                city_id: city_id,
                city_str: city_str,
                area_id: area_id,
                area_str: area_str,
                address: that.data.address,
            },
            header: app.getRequestHeader(),
            success(res) {
                console.log(res.data)
                if (res.data.code == 1) {

                }
            }
        })


    },
    deleteAddress: function (e) {

    },
});
