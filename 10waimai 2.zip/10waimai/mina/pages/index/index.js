//login.js
//获取应用实例
var app = getApp();
Page({
    data: {
        remind: '加载中',
        angle: 0,
        userInfo: {},
        islogin: false
    },
    goToIndex: function () {
        wx.switchTab({
            url: '/pages/food/index',
        });
    },
    onLoad: function () {
        wx.setNavigationBarTitle({
            title: app.globalData.shopName
        })

        this.checklogin()
    },
    onShow: function () {

    },
    onReady: function () {
        var that = this;
        setTimeout(function () {
            that.setData({
                remind: ''
            });
        }, 1000);
        wx.onAccelerometerChange(function (res) {
            var angle = -(res.x * 30).toFixed(1);
            if (angle > 14) {
                angle = 14;
            } else if (angle < -14) {
                angle = -14;
            }
            if (that.data.angle !== angle) {
                that.setData({
                    angle: angle
                });
            }
        });
    },

    bindGetUserInfo: function () {
        wx.getUserInfo({
            success: function (res) {
                var userInfo = res.userInfo
                var nickName = userInfo.nickName
                var avatarUrl = userInfo.avatarUrl
                var gender = userInfo.gender //性别 0：未知、1：男、2：女
                wx.login({
                    success(res) {
                        if (res.code) {
                            //发起网络请求
                            wx.request({
                                url: app.buildUrl('/v1/user/login'),
                                method: "POST",
                                data: {
                                    code: res.code,
                                    nickName: nickName,
                                    avatarUrl: avatarUrl,
                                    gender: gender,
                                },
                                header:app.getRequestHeader(),
                                success(res) {
                                    console.log(res.data)
                                    if (res.data.code == 1) {

                                        //存起来

                                        app.setToken('token', res.data.data.token)
                                        wx.switchTab({
                                            url: '/pages/food/index',
                                        });
                                    } else {
                                        wx.showToast({
                                            title: '失败',
                                            icon: 'fail',
                                            duration: 1000,
                                            mask: true
                                        })
                                    }
                                }
                            })
                        } else {
                            console.log('登录失败！' + res.errMsg)
                        }
                    }
                })


            }
        })
    },

    checklogin: function () {
        var that = this
        wx.login({
            success(res) {
                if (res.code) {
                    //发起网络请求
                    wx.request({
                        url: app.buildUrl('/v1/user/checklogin'),
                        method: "POST",
                        data: {
                            code: res.code,
                        },
                        header: app.getRequestHeader(),
                        success(res) {
                            console.log(res.data)
                            if (res.data.code == 1) {
                                app.setToken('token', res.data.data.token)
                                that.setData({

                                    islogin: true
                                })
                            }
                        }
                    })
                } else {
                    console.log('登录失败！' + res.errMsg)
                }
            }
        })


    }


});