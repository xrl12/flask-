from app.libs.redprint import RedPrint
from app.models.user import Member, OauthMemberBind
from flask import request, current_app, jsonify
import requests
from app import db
import hashlib
from app.service.member_service import MemberService

api = RedPrint('user', description='用户模块')


def geneAuthCode(member=None):
    m = hashlib.md5()
    str = "%s-%s-%s" % (member.id, member.salt, member.status)
    m.update(str.encode("utf-8"))
    return m.hexdigest()


@api.route('/login', methods=['POST'])
def index():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}
    code = request.form.get('code')
    nickName = request.form.get('nickName')
    avatarUrl = request.form.get('avatarUrl')
    gender = request.form.get('gender')
    print(code, nickName, avatarUrl, gender)

    app_id = current_app.config.get('APP_ID')
    secret = current_app.config.get('SECRET')
    url = 'https://api.weixin.qq.com/sns/jscode2session?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code' % (
        app_id, secret, code)
    response = requests.get(url)

    open_id = response.json().get('openid')

    if not open_id:
        ctx['code'] = -1
        ctx['msg'] = '获取open_id出差'

        return jsonify(ctx)

    oauthmemberbind = OauthMemberBind.query.filter_by(openid=open_id).first()
    if not oauthmemberbind:
        try:
            member = Member()
            member.nickname = nickName
            member.avatar = avatarUrl
            member.gender = gender
            member.salt = MemberService.getSalt()
            db.session.add(member)
            db.session.commit()

            oauthmemberbind = OauthMemberBind()
            oauthmemberbind.openid = open_id
            oauthmemberbind.client_type = 'weixin'
            oauthmemberbind.type = 1
            oauthmemberbind.member_id = member.id
            db.session.add(oauthmemberbind)
            db.session.commit()
        except Exception as e:
            pass

    member = oauthmemberbind.member
    token = MemberService.geneAuthCode(member)
    ctx['data']['token'] = '%s#%s' % (member.id, token)
    return jsonify(ctx)


@api.route('/checklogin', methods=['POST'])
def checklogin():
    print('111')
    ctx = {'code': 1, 'msg': "ok", 'data': {}}
    code = request.form.get('code')
    app_id = current_app.config.get('APP_ID')
    secret = current_app.config.get('SECRET')
    url = 'https://api.weixin.qq.com/sns/jscode2session?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code' % (
        app_id, secret, code)
    response = requests.get(url)
    print(response.json())
    open_id = response.json().get('openid')

    if not open_id:
        ctx['code'] = -1
        ctx['msg'] = '获取open_id出差'

        return jsonify(ctx)
    print('12312312')
    oauthmemberbind = OauthMemberBind.query.filter_by(openid=open_id).first()

    if not oauthmemberbind:
        ctx['code'] = -1
        ctx['msg'] = '用户不存在'

    member = oauthmemberbind.member
    token = MemberService.geneAuthCode(member)
    ctx['data']['token'] = '%s#%s' % (member.id, token)

    return jsonify(ctx)
