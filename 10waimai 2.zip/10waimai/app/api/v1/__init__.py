from flask import Blueprint
from . import user
from . import food
from . import cart
from . import order
from . import address


def createBluePrint():
    bp = Blueprint('v1', __name__)
    user.api.register(bp)  # 把红图注册的路由交给蓝图
    food.api.register(bp)  # 把红图注册的路由交给蓝图
    cart.api.register(bp)  # 把红图注册的路由交给蓝图
    order.api.register(bp)  # 把红图注册的路由交给蓝图
    address.api.register(bp)  # 把红图注册的路由交给蓝图
    return bp
