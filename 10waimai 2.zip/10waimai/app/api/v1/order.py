from app.libs.redprint import RedPrint
from app.models.cart import MemberCart
from app.models.food import Food
from app.models.user import Member
from app.models.user import OauthMemberBind
from app.models.address import MemberAddress
from app.service.member_service import MemberService
from flask import request, current_app, jsonify
from app.utils.common import buildPicUrl
from app import db
from app.models.order import *
from app.models.address import *
import json
from app.service.WeChatService import WeChatService

api = RedPrint('order', description='订单模块')


@api.route('/info', methods=['POST'])
def info():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}

    token = request.headers.get('Token')  # id#hkdshajdgjsag

    uid, token = token.split('#')

    member = Member.query.get(uid)

    token1 = MemberService.geneAuthCode(member)

    if token1 != token:
        ctx['code'] = -1
        ctx['msg'] = '用户异常'
        return jsonify(ctx)

    '''
    
      goods_list: [
            {
                id: 22,
                name: "小鸡炖蘑菇",
                price: "85.00",
                pic_url: "/images/food.jpg",
                number: 1,
            },
            {
                id: 22,
                name: "小鸡炖蘑菇",
                price: "85.00",
                pic_url: "/images/food.jpg",
                number: 1,
            }
        ],
        default_address: {
            name: "12321312",
            mobile: "12345678901",
            detail: "上海市浦东新区XX",
        },
        yun_price: "1.00",
        pay_price: "85.00",
        total_price: "86.00",
        params: null,
        ids: '',
    },
    '''

    ids = request.form.get('ids')  # 商品的ids
    ids = json.loads(ids)
    goods_list = []

    memberaddress = MemberAddress.query.filter_by(is_default=1).first()
    if memberaddress:
        default_address = {  # 取默认地址
            'id': memberaddress.id,
            'name': memberaddress.nickname,
            'mobile': memberaddress.mobile,
            'detail': memberaddress.showAddress,
        }
    else:
        default_address = {}

    pay_price = 0
    for id in ids:
        food = Food.query.get(id)
        temp = {}
        temp['id'] = food.id
        temp['name'] = food.name
        temp['price'] = str(food.price)
        temp['pic_url'] = buildPicUrl(food.main_image)

        membercart = MemberCart.query.filter_by(member_id=member.id, food_id=food.id).first()
        temp['number'] = membercart.quantity

        pay_price += food.price * membercart.quantity

        goods_list.append(temp)

    ctx['data']['goods_list'] = goods_list
    ctx['data']['default_address'] = default_address
    ctx['data']['yun_price'] = 0
    ctx['data']['pay_price'] = str(pay_price)
    ctx['data']['total_price'] = str(pay_price)
    return jsonify(ctx)


import hashlib
import time
import random


def geneOrderSn():
    m = hashlib.md5()
    sn = None
    while True:
        str = "%s-%s" % (int(round(time.time() * 1000)), random.randint(0, 9999999))
        m.update(str.encode("utf-8"))
        sn = m.hexdigest()
        if not PayOrder.query.filter_by(order_sn=sn).first():
            break
    return sn


@api.route('/create', methods=['POST'])
def create():
    try:
        ctx = {'code': 1, 'msg': "ok", 'data': {}}

        token = request.headers.get('Token')  # id#hkdshajdgjsag

        uid, token = token.split('#')

        member = Member.query.get(uid)

        token1 = MemberService.geneAuthCode(member)

        if token1 != token:
            ctx['code'] = -1
            ctx['msg'] = '用户异常'
            return jsonify(ctx)

        ids = request.form.get('ids')  # 商品的ids

        note = request.form.get('note')

        address_id = request.form.get('address_id')

        memberaddress = MemberAddress.query.get(address_id)
        if not memberaddress:
            ctx['code'] = -1
            ctx['msg'] = '地址不存在'
            return jsonify(ctx)

        ids = json.loads(ids)

        pay_price = 0
        yun_price = 0
        for id in ids:
            membercart = MemberCart.query.filter_by(member_id=member.id, food_id=id).first()

            food = Food.query.get(id)

            pay_price += food.price * membercart.quantity  # 商品的价格 *购物车数量

        total_price = pay_price + yun_price

        # 找购物车

        payorder = PayOrder()

        payorder.order_sn = geneOrderSn()
        payorder.total_price = total_price
        payorder.yun_price = 0
        payorder.pay_price = pay_price
        payorder.note = note
        payorder.status = -8
        payorder.express_address_id = address_id
        payorder.express_info = memberaddress.nickname + ' ' + memberaddress.mobile + ' ' + memberaddress.showAddress
        payorder.member_id = member.id

        db.session.add(payorder)

        foods = db.session.query(Food).filter(Food.id.in_(ids)).with_for_update().all()  # 悲观锁
        temp_stock = {}
        for food in foods:
            temp_stock[food.id] = food.stock

        for id in ids:

            food = Food.query.get(id)
            membercart = MemberCart.query.filter_by(member_id=member.id, food_id=id).first()

            if membercart.quantity > temp_stock[id]:  # 引入风控
                ctx['code'] = -1
                ctx['msg'] = '库存不足'
                return jsonify(ctx)

            f = db.session.query(Food).filter(Food.id == id).update({
                'stock': temp_stock[id] - membercart.quantity
            })
            if not f:
                ctx['code'] = -1
                ctx['msg'] = '更新失败'
                return jsonify(ctx)
            payorderitem = PayOrderItem()
            payorderitem.quantity = membercart.quantity
            payorderitem.price = food.price
            payorderitem.note = note
            payorderitem.status = 1
            payorderitem.pay_order_id = payorder.id
            payorderitem.member_id = member.id
            payorderitem.food_id = food.id

            db.session.add(payorderitem)
        db.session.commit()

        for id in ids:
            membercart = MemberCart.query.filter_by(member_id=member.id, food_id=id).first()
            db.session.delete(membercart)
            db.session.commit()

        return jsonify(ctx)
    except Exception:
        db.rollback()


@api.route('/list', methods=['GET'])
def list():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}

    token = request.headers.get('Token')  # id#hkdshajdgjsag

    uid, token = token.split('#')

    member = Member.query.get(uid)

    token1 = MemberService.geneAuthCode(member)

    if token1 != token:
        ctx['code'] = -1
        ctx['msg'] = '用户异常'
        return jsonify(ctx)

    status = request.args.get('status')

    payorders = PayOrder.query.filter_by(member_id=member.id, status=status).all()
    '''
    order_list: [
                {
					status: -8,
                    status_desc: "待支付",
                    date: "2018-07-01 22:30:23",
                    order_number: "20180701223023001",
                    note: "记得周六发货",
                    total_price: "85.00",
                    goods_list: [
                        {
                            pic_url: "/images/food.jpg"
                        },
                        {
                            pic_url: "/images/food.jpg"
                        }
                    ]
                }
            ]
    '''

    order_list = []
    for order in payorders:
        temp = {}
        temp['status'] = order.status
        temp['status_desc'] = order.status_desc
        temp['date'] = order.pay_time
        temp['order_number'] = order.order_sn
        temp['note'] = order.note
        temp['total_price'] = str(order.total_price)

        goods_list = []
        payorderitems = PayOrderItem.query.filter_by(pay_order_id=order.id).all()

        for item in payorderitems:
            food = Food.query.get(item.food_id)
            pic = {}
            pic['pic_url'] = buildPicUrl(food.main_image)
            goods_list.append(pic)
        temp['goods_list'] = goods_list

        order_list.append(temp)
    ctx['data']['order_list'] = order_list

    return jsonify(ctx)


@api.route('/pay', methods=['POST'])
def pay():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}

    token = request.headers.get('Token')  # id#hkdshajdgjsag

    uid, token = token.split('#')

    member = Member.query.get(uid)

    token1 = MemberService.geneAuthCode(member)

    if token1 != token:
        ctx['code'] = -1
        ctx['msg'] = '用户异常'
        return jsonify(ctx)

    # order_sn = request.form.get('order_sn')
    #
    # # 去库找到该订单
    # pay_order_info = PayOrder.query.filter_by(order_sn=order_sn, member_id=member.id).first()
    #
    # if not pay_order_info:
    #     ctx['code'] = -1
    #     ctx['msg'] = "系统繁忙。请稍后再试~"
    #     return jsonify(ctx)
    #
    # # 找到该会员的信息
    # oauth_bind_info = OauthMemberBind.query.filter_by(member_id=member.id).first()
    # if not oauth_bind_info:
    #     ctx['code'] = -1
    #     ctx['msg'] = "系统繁忙。请稍后再试~~2"
    #     return jsonify(ctx)
    #
    # # http://127.0.0.1:5000/api/v1/order/callback
    #
    # # 为了将来推送支付结果
    # target_wechat = WeChatService(merchant_key=current_app.config['PAYKEY'])  # 商户密钥 目前没有
    #
    # data = {
    #     'appid': current_app.config['APP_ID'],  # 小程序id
    #     'mch_id': current_app.config['MCH_ID'],  # 商户号没有
    #     'nonce_str': target_wechat.get_nonce_str(),  # 随机字符串
    #     'body': '订餐',  # 商品描述
    #     'out_trade_no': pay_order_info.order_sn,  # order_sn
    #     'total_fee': int(pay_order_info.total_price * 100),  # 钱  单位是分
    #     'notify_url': current_app.config['notify_url'],  # 回调地址
    #     'trade_type': "JSAPI",  # jsai
    #     'openid': oauth_bind_info.openid,  # 开发平台的id
    #     'spbill_create_ip': '127.0.0.1'  # ip地址
    # }
    #
    # #
    # pay_info = target_wechat.get_pay_info(pay_data=data)
    #
    # # # 保存prepay_id为了后面发模板消息
    # pay_order_info.prepay_id = pay_info['prepay_id']
    # db.session.add(pay_order_info)
    # db.session.commit()

    '''
    
    '''

    pay_sign_data = {
        'timeStamp': '4535434534',  # 时间戳
        'nonceStr': "adskhjasghjdas",  # 随机字符串
        'package': 'prepay_id=123456789',  # 数据包
        'signType': 'MD5',
        'paySign': '21361263571265hggasdfghgas'
    }

    ctx['data']['pay_info'] = pay_sign_data

    return jsonify(ctx)


@api.route("/callback", methods=["POST"])
def orderCallback():
    result_data = {
        'return_code': 'SUCCESS',
        'return_msg': 'OK'
    }
    header = {'Content-Type': 'application/xml'}
    target_wechat = WeChatService(merchant_key=current_app.config['PAYKEY'])
    # 解析微信推送过来的xml 支付结果  改成字典
    callback_data = target_wechat.xml_to_dict(request.data)

    # 取出这里面sign
    sign = callback_data['sign']

    # 在pop掉sign
    callback_data.pop('sign')

    # 在把这个字典进行签名 返回一个sign
    gene_sign = target_wechat.create_sign(callback_data)  # 在加密
    # 如果取出的sign和加密后的sign不一样
    if sign != gene_sign:
        result_data['return_code'] = result_data['return_msg'] = 'FAIL'
        return target_wechat.dict_to_xml(result_data), header
    # 如果返回的不等于成功
    if callback_data['result_code'] != 'SUCCESS':
        result_data['return_code'] = result_data['return_msg'] = 'FAIL'
        return target_wechat.dict_to_xml(result_data), header
    # 订单号取出来
    order_sn = callback_data['out_trade_no']

    # 根据订单查这个订单的信息
    pay_order_info = PayOrder.query.filter_by(order_sn=order_sn).first()
    if not pay_order_info:
        result_data['return_code'] = result_data['return_msg'] = 'FAIL'
        return target_wechat.dict_to_xml(result_data), header

    # 如果付款的金额和推送过来的支付金额不一样
    if int(pay_order_info.total_price * 100) != int(callback_data['total_fee']):
        result_data['return_code'] = result_data['return_msg'] = 'FAIL'
        return target_wechat.dict_to_xml(result_data), header

    if pay_order_info.status == -8:
        return target_wechat.dict_to_xml(result_data), header

    # 把订单更新待发货
    # OrderService.orderSuccess(pay_order_id=pay_order_info.id, params={"pay_sn": callback_data['transaction_id']})
    #把支付结果存起来
    return target_wechat.dict_to_xml(result_data), header


'''
1、生成订单
2、扣库存
3、清空购物车（只限购物车生成的订单）



1、黑龙江123买了一个商品 商品以收获

2、改成黑龙江456






订单表：
    
    
   1订单-----> 2件商品
   
   
   收获地址表
   
   
   订单表
   
    总价格
    
    订单状态
    
    地址的具体
    # 地址的主键
    
    
    付款时间
    
    创建时间
    
    用户id
   
   
   
   订单商品表
   
    1、food_id
    
    
    
   2、 
    商品的名字
    商品的价格
    商品的xxx
    
    
    
    
    
    1、先生成订单 
    
        订单  发现库存不够
    
         
    
   2、 还是先扣库存
             
        库存不够 到底要不要生成订单
        
        
     0   
    500
    
    
    一个人：500   二个人500      
     0-500     -500-500 
         
        
   我再扣库存的时候，
   
   
   
   表锁 
   
   行锁 ：
        1、悲观锁 、我再改的时候，不允许其他事物进修改数据
        
        2、乐观锁   我查的时候我 这行里面存version=1    
        
             
    
    
   索引
   
   事物
   
    锁     

    
'''
