from app.libs.redprint import RedPrint
from app.models.cart import MemberCart
from app.models.food import Food
from app.models.user import Member
from app.service.member_service import MemberService
from flask import request, current_app, jsonify
from app.utils.common import buildPicUrl
from app.models.address import MemberAddress
from app import db
import json

api = RedPrint('address', description='地址模块')


@api.route('/set', methods=['POST'])
def add():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}

    token = request.headers.get('Token')  # id#hkdshajdgjsag
    uid, token = token.split('#')

    member = Member.query.get(uid)

    token1 = MemberService.geneAuthCode(member)

    if token1 != token:
        ctx['code'] = -1
        ctx['msg'] = '用户异常'
        return jsonify(ctx)

    nickname = request.form.get('nickname')
    mobile = request.form.get('mobile')
    province_id = request.form.get('province_id')
    province_str = request.form.get('province_str')
    city_id = request.form.get('city_id')
    city_str = request.form.get('city_str')
    area_id = request.form.get('area_id')
    area_str = request.form.get('area_str')
    address = request.form.get('address')

    ma = MemberAddress.query.filter_by(is_default=1).all()

    if not nickname:
        ctx['code'] = -1
        ctx['msg'] = '名字不能为空'
        return jsonify(ctx)

    memberaddress = MemberAddress()
    memberaddress.nickname = nickname
    memberaddress.mobile = mobile
    memberaddress.province_id = province_id  # 验证
    memberaddress.province_str = province_str
    memberaddress.city_id = city_id
    memberaddress.city_str = city_str
    memberaddress.area_id = area_id
    memberaddress.area_str = area_str
    memberaddress.address = address
    memberaddress.member_id = member.id

    if not ma:

        memberaddress.is_default = 1
    else:
        memberaddress.is_default = 0

    db.session.add(memberaddress)

    db.session.commit()
    return jsonify(ctx)


@api.route('/list', methods=['POST'])
def list():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}

    token = request.headers.get('Token')  # id#hkdshajdgjsag
    uid, token = token.split('#')

    member = Member.query.get(uid)

    token1 = MemberService.geneAuthCode(member)

    if token1 != token:
        ctx['code'] = -1
        ctx['msg'] = '用户异常'
        return jsonify(ctx)

    memberaddresses = MemberAddress.query.filter_by(member_id=member.id).all()

    '''
    {
                    id: 2,
                    name: "test2",
                    mobile: "12345678901",
                    detail: "上海市浦东新区XX"
                }
    '''
    addressList = []
    for memberaddress in memberaddresses:
        temp = {}
        temp['id'] = memberaddress.id
        temp['name'] = memberaddress.nickname
        temp['mobile'] = memberaddress.mobile
        temp['isDefault'] = memberaddress.is_default
        temp[
            'detail'] = memberaddress.province_str + memberaddress.city_str + memberaddress.area_str + memberaddress.address

        addressList.append(temp)

    ctx['data']['addressList'] = addressList
    return jsonify(ctx)
