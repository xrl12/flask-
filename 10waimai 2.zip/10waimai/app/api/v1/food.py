from app.libs.redprint import RedPrint
from app.models.user import Member, OauthMemberBind
from flask import request, current_app, jsonify
import requests
from app import db
import hashlib
from app.service.member_service import MemberService
from app.models.food import *

from app.utils.common import buildPicUrl

api = RedPrint('food', description='食品模块')


@api.route('/banners', methods=['GET'])
def banners():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}

    foods = Food.query.limit(3).all()

    banners = [
    ]
    for food in foods:
        temp = {}
        temp['id'] = food.id
        temp['pic_url'] = buildPicUrl(food.main_image)
        banners.append(temp)
    ctx['data']['banners'] = banners

    return jsonify(ctx)


@api.route('/categories', methods=['GET'])
def cetegories():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}

    cats = Category.query.filter_by(status=1).all()

    categories = [

    ]
    categories.append(

        {'id': 0, 'name': "全部"}
    )
    for cat in cats:
        temp = {}
        temp['id'] = cat.id
        temp['name'] = cat.name
        categories.append(temp)
    ctx['data']['categories'] = categories
    return jsonify(ctx)


@api.route('/list', methods=['GET'])
def list():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}

    try:
        cid = int(request.args.get('cid'))
        page = int(request.args.get('page'))

        if page <= 0:
            page = 1

        if cid == 0:
            fs = Food.query.filter_by(status=1)
        else:

            fs = Food.query.filter_by(cat_id=cid, status=1)

        pagesize = 1
        offset = (page - 1) * pagesize
        fs = fs.offset(offset).limit(1).all()

        foods = []
        for food in fs:
            temp = {}
            temp['id'] = food.id
            temp['name'] = food.name
            temp['price'] = str(food.price)
            temp['min_price'] = str(round(float(food.price) * 0.8, 2))
            temp['pic_url'] = buildPicUrl(food.main_image)
            foods.append(temp)

        ctx['data']['foods'] = foods

        if len(fs) < 1:
            ctx['data']['ismore'] = 0
        else:
            ctx['data']['ismore'] = 1
        # time.sleep(5)
        return jsonify(ctx)
    except Exception as e:
        ctx['code'] = -1
        ctx['msg'] = '参数有误'
        return jsonify(ctx)


@api.route('/info')
def info():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}
    # 接到商品的id

    gid = request.args.get('gid')

    food = Food.query.get(gid)
    if food:
        food_info = {
            "id": food.id,
            "name": food.name,
            "summary": food.summary,
            "total_count": food.total_count,
            "comment_count": food.comment_count,
            "stock": food.stock,
            "price": str(round(float(food.price) * 0.8, 2)),
            "main_image": buildPicUrl(food.main_image),
            "pics": [buildPicUrl(food.main_image), buildPicUrl(food.main_image)]
        }

        ctx['data']['info'] = food_info
        return jsonify(ctx)
    else:
        ctx['code'] = -1
        ctx['msg'] = '不存在'
        return jsonify(ctx)


'''

轮播图表

    排序
    图片    
    商品id
    是否展示


分类表
    排序
    名字
    是否下架

食品表

    名字
    价格 80
    真实价格  50    
    介绍
    图片 一张
    是否下架
    
    库存
    
    
    
数据怎么添加？


用可视化数据之间操作数据库

如果建轮播图表，就从该表查
如果没有建，就取食品表前3个

    
    


一个商品 对应多个图片


商品表
    image = 'xxxxxxxx'
    



图片表
    
    food_id = xxx
    
    
以空间换时间


    
    
购物车

id

food_id

count

user_id



    

'''
