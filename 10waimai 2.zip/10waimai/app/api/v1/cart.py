from app.libs.redprint import RedPrint
from app.models.cart import MemberCart
from app.models.food import Food
from app.models.user import Member
from app.service.member_service import MemberService
from flask import request, current_app, jsonify
from app.utils.common import buildPicUrl
from app import db
import json

api = RedPrint('cart', description='购物车模块')


@api.route('/add', methods=['POST'])
def add():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}

    # id    food_id  user_id num
    #
    # 1       1        1      3
    #
    # 1       2       1       2

    id = request.form.get('id')  # 商品的id

    try:
        number = int(request.form.get('number'))

    except Exception:
        ctx['code'] = -1
        ctx['msg'] = '数量异常'
        return jsonify(ctx)

    token = request.headers.get('Token')  # id#hkdshajdgjsag
    membercart = MemberCart.query.filter_by(food_id=id).first()

    food = Food.query.filter_by(id=id, status=1).first()

    if not food:
        ctx['code'] = -1
        ctx['msg'] = '商品状态异常'
        return jsonify(ctx)

    if number < 1 or number > food.stock:
        ctx['code'] = -1
        ctx['msg'] = '库存不在'
        return jsonify(ctx)

    uid, token = token.split('#')

    member = Member.query.get(uid)

    token1 = MemberService.geneAuthCode(member)

    if token1 != token:
        ctx['code'] = -1
        ctx['msg'] = '用户异常'
        return jsonify(ctx)

    if not membercart:
        cart = MemberCart()
        cart.food_id = id
        cart.member_id = member.id
        cart.quantity = number
        db.session.add(cart)
        db.session.commit()
    else:
        membercart.quantity = membercart.quantity + number
        db.session.add(membercart)
        db.session.commit()

    return jsonify(ctx)


@api.route('/list', methods=['POST'])
def list():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}

    token = request.headers.get('Token')  # id#hkdshajdgjsag

    uid, token = token.split('#')

    member = Member.query.get(uid)

    token1 = MemberService.geneAuthCode(member)

    if token1 != token:
        ctx['code'] = -1
        ctx['msg'] = '用户异常'
        return jsonify(ctx)

    membercarts = MemberCart.query.filter_by(member_id=member.id).all()
    print(membercarts)
    '''
    
    {
            //     "id": 1080,
            //     "food_id": "5",
            //     "pic_url": "/images/food.jpg",
            //     "name": "小鸡炖蘑菇-1",
            //     "price": "85.00",
            //     "active": true,
            //     "number": 1
            // },
    '''
    l = []
    totalPrice = 0
    for cart in membercarts:
        food = Food.query.get(cart.food_id)
        temp = {}
        temp['id'] = cart.id
        temp['food_id'] = food.id
        temp['pic_url'] = buildPicUrl(food.main_image)
        temp['price'] = str(food.price)
        temp['active'] = 'true'
        temp['number'] = cart.quantity
        totalPrice += cart.quantity * food.price
        l.append(temp)

    ctx['data']['list'] = l
    ctx['data']['totalPrice'] = str(totalPrice)
    return jsonify(ctx)


@api.route('/edit', methods=['POST'])
def edit():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}

    token = request.headers.get('Token')  # id#hkdshajdgjsag

    uid, token = token.split('#')

    member = Member.query.get(uid)

    token1 = MemberService.geneAuthCode(member)

    if token1 != token:
        ctx['code'] = -1
        ctx['msg'] = '用户异常'
        return jsonify(ctx)
    try:
        number = int(request.form.get('number'))

        if number != 1 and number != -1:
            ctx['code'] = -1
            ctx['msg'] = '数量不对'
            return jsonify(ctx)

    except Exception:
        ctx['code'] = -1
        ctx['msg'] = '数量不对'
        return jsonify(ctx)
    food_id = request.form.get('food_id')

    membercart = MemberCart.query.filter_by(food_id=food_id, member_id=member.id).first()
    if not membercart:
        ctx['code'] = -1
        ctx['msg'] = '购物车不存在'
        return jsonify(ctx)
    membercart.quantity = membercart.quantity + number

    if membercart.quantity > 20 or membercart.quantity < 1:
        ctx['code'] = -1
        ctx['msg'] = '购物车数量不对'
        return jsonify(ctx)
    db.session.add(membercart)
    db.session.commit()

    return jsonify(ctx)


@api.route('/del', methods=['POST'])
def delete():
    ctx = {'code': 1, 'msg': "ok", 'data': {}}

    token = request.headers.get('Token')  # id#hkdshajdgjsag

    uid, token = token.split('#')

    member = Member.query.get(uid)

    token1 = MemberService.geneAuthCode(member)

    if token1 != token:
        ctx['code'] = -1
        ctx['msg'] = '用户异常'
        return jsonify(ctx)

    ids = request.form.get('ids')  # '[1,2]'

    ids = json.loads(ids)

    for id in ids:
        membercart = MemberCart.query.filter_by(member_id=member.id, id=id).first()

        if membercart:
            db.session.delete(membercart)
            db.session.commit()

    return jsonify(ctx)


'''
http://127.0.0.5000?token=1#qweasdzxc    status=1
             
                                         status=0
http://127.0.0.5000?token=1#sahdjgasjgd

http://127.0.0.5000?token=3#qweasdzxc




10.8 购物车加入商品A

10.9 商品A下架了

10.10 进入购物车 ，商品还在不在？


id   food-id   num   uid
1    1         2     2
1    1         2     3
'''
