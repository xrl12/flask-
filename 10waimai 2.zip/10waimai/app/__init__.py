from flask import Flask
from config import config_mapping
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from flask_babelex import Babel
from flask_login import LoginManager

login_manager = LoginManager()

login_manager.login_view = 'admin.login'

'''
蓝图用区分版本
红图区分模块
'''

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


def create_app(config):
    app = Flask(__name__)

    app.config.from_object(config_mapping[config])

    db.init_app(app)

    # 绑定app
    login_manager.init_app(app)

    babel = Babel(app)

    from app.api.v1 import createBluePrint
    app.register_blueprint(createBluePrint(), url_prefix='/api/v1')

    from app.admin import admin_page
    app.register_blueprint(admin_page, url_prefix='/admin')

    from app.models.food import Category, Food
    admin = Admin(app, name="订餐管理系统", template_mode='bootstrap3', base_template='admin/mybase.html')
    admin.add_view(ModelView(Category, db.session, name='分类'))

    from app.admin.modelview import FModelview
    admin.add_view(FModelview(Food, db.session, name='食品'))

    return app
