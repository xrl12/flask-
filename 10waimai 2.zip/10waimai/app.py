from app import create_app, db

from flask_migrate import Manager

from flask_migrate import Migrate, MigrateCommand

import pymysql

pymysql.install_as_MySQLdb()

app = create_app('dev')

Migrate(app=app, db=db)

manger = Manager(app=app)

manger.add_command('db', MigrateCommand)

if __name__ == '__main__':
    # app.run()
    manger.run()
